/* ============ KONFIGURASI — edit di sini ============ */
const weddingConfig = {
  bride: "Mawarda Sholeha",
  groom: "Arjun Nur Alfantori",
  date: "7 November 2026",
  akadTime: "08.00 WIB",
  receptionTime: "10.00 WIB",
  whatsapp: "ISI_NOMOR",          // format internasional tanpa +, contoh: 6281234567890
  mapsUrl: "",                     // kosongkan = otomatis dari alamat. Atau isi link Google Maps sendiri.
  address: "Jl. Aru Jajar, Perumahan Puri Bandara Blok A No. 16, RT. 08 RW. 03, Kelurahan Pekan Sabtu, Kecamatan Selebar, Kota Bengkulu",
  addressHtml: "Jl. Aru Jajar, Perumahan Puri Bandara<br>Blok A No. 16, RT. 08 RW. 03<br>Kelurahan Pekan Sabtu, Kecamatan Selebar<br>Kota Bengkulu",
  eventStartISO: "2026-11-07T08:00:00+07:00",
  rsvpEndpoint: ""                 // URL Google Apps Script / Firebase function. Kosong = mode demo (localStorage)
};

/* ============ Helper ============ */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
const toast = (msg) => { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove("show"), 2600); };
const esc = (s) => s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const mapsLink = weddingConfig.mapsUrl || "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(weddingConfig.address);

/* ============ Isi alamat & link maps ============ */
["addr1", "addr2", "addr3"].forEach(id => { $("#" + id).innerHTML = weddingConfig.addressHtml; });
$$("[data-maps]").forEach(a => a.href = mapsLink);
$("#mapFrame").src = "https://www.google.com/maps?q=" + encodeURIComponent(weddingConfig.address) + "&output=embed";
const waText = "Halo Mawar & Arjun, saya ingin mengonfirmasi kehadiran untuk acara pernikahan tanggal 7 November 2026.";
$("#waBtn").href = "https://wa.me/" + weddingConfig.whatsapp + "?text=" + encodeURIComponent(waText);
$("#waBtn").addEventListener("click", e => { if (weddingConfig.whatsapp === "ISI_NOMOR") { e.preventDefault(); toast("Nomor WhatsApp belum diisi di script.js"); } });

/* ============ Cover & musik ============ */
const audio = $("#audio"), music = $("#music");
function setMusicUI(on) { music.classList.toggle("playing", on); $("#musicStatus").textContent = on ? "Playing" : "Paused"; }
audio.volume = .6;
$("#openBtn").addEventListener("click", () => {
  $("#envelope").classList.add("opened");
  $("#openBtn").disabled = true;
  audio.play().then(() => setMusicUI(true)).catch(() => setMusicUI(false));
  music.hidden = false;
  setTimeout(() => { $("#cover").classList.add("gone"); document.body.classList.remove("locked"); window.scrollTo(0, 0); }, reduce ? 300 : 2200);
});
$("#musicBtn").addEventListener("click", () => { if (audio.paused) audio.play().then(() => setMusicUI(true)).catch(() => toast("File musik belum ditemukan di /audio")); else { audio.pause(); setMusicUI(false); } });
$("#muteBtn").addEventListener("click", e => { audio.muted = !audio.muted; e.currentTarget.textContent = audio.muted ? "🔇" : "🔊"; });
$("#vol").addEventListener("input", e => { audio.volume = e.target.value; });

/* ============ Reveal saat scroll ============ */
const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: .15 });
const observe = () => $$(".rv:not(.in),.line:not(.in),.ph:not(.in),.gi:not(.in)").forEach(el => io.observe(el));

/* ============ Galeri + lightbox (15 foto) ============ */
const photos = Array.from({ length: 15 }, (_, i) => `images/${String(i + 1).padStart(2, "0")}.jpg`);
const grid = $("#galleryGrid");
photos.forEach((src, i) => {
  const b = document.createElement("button");
  b.className = "gi"; b.setAttribute("aria-label", "Buka foto " + (i + 1));
  b.innerHTML = `<img src="${src}" alt="Foto galeri Mawar dan Arjun ${i + 1}" loading="lazy" decoding="async">`;
  b.firstChild.onerror = function () { this.remove(); };
  b.addEventListener("click", () => openLB(i));
  grid.appendChild(b);
});
const lb = $("#lb"), lbImg = $("#lbImg"); let cur = 0;
function showLB(i) { cur = (i + photos.length) % photos.length; lbImg.style.opacity = 0; setTimeout(() => { lbImg.src = photos[cur]; lbImg.alt = "Foto galeri " + (cur + 1); lbImg.style.opacity = 1; }, 200); }
function openLB(i) { lb.hidden = false; requestAnimationFrame(() => lb.classList.add("show")); lbImg.src = photos[i]; cur = i; document.body.classList.add("locked"); $("#lbX").focus(); }
function closeLB() { lb.classList.remove("show"); setTimeout(() => { lb.hidden = true; document.body.classList.remove("locked"); }, 450); }
$("#lbX").onclick = closeLB; $("#lbP").onclick = () => showLB(cur - 1); $("#lbN").onclick = () => showLB(cur + 1);
lb.addEventListener("click", e => { if (e.target === lb) closeLB(); });
document.addEventListener("keydown", e => { if (lb.hidden) return; if (e.key === "Escape") closeLB(); if (e.key === "ArrowLeft") showLB(cur - 1); if (e.key === "ArrowRight") showLB(cur + 1); });
let sx = 0;
lb.addEventListener("touchstart", e => { sx = e.touches[0].clientX; }, { passive: true });
lb.addEventListener("touchend", e => { const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) showLB(cur + (dx < 0 ? 1 : -1)); }, { passive: true });

/* ============ Countdown ============ */
const target = new Date(weddingConfig.eventStartISO).getTime();
function tick() {
  const d = target - Date.now();
  if (d <= 0) { $("#cd").hidden = true; $("#arrived").hidden = false; return; }
  const p = n => String(n).padStart(2, "0");
  $("#cdD").textContent = p(Math.floor(d / 864e5)); $("#cdH").textContent = p(Math.floor(d % 864e5 / 36e5));
  $("#cdM").textContent = p(Math.floor(d % 36e5 / 6e4)); $("#cdS").textContent = p(Math.floor(d % 6e4 / 1e3));
}
tick(); setInterval(tick, 1000);

/* ============ Add to calendar (.ics) ============ */
$("#calBtn").addEventListener("click", () => {
  const ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Undangan Mawar Arjun//ID", "BEGIN:VEVENT",
    "UID:arjun-mawarda-20261107@undangan", "DTSTAMP:20260101T000000Z",
    "DTSTART:20261107T010000Z", "DTEND:20261107T060000Z",   // 08.00–13.00 WIB
    "SUMMARY:Pernikahan Mawar & Arjun", "DESCRIPTION:Akad 08.00 WIB - Resepsi 10.00 WIB",
    "LOCATION:" + weddingConfig.address.replace(/,/g, "\\,"), "END:VEVENT", "END:VCALENDAR"].join("\r\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([ics], { type: "text/calendar" })); a.download = "pernikahan-arjun-mawarda.ics";
  a.click(); toast("Event kalender diunduh.");
});

/* ============ Salin rekening ============ */
$$("[data-copy]").forEach(b => b.addEventListener("click", async () => {
  const v = b.dataset.copy;
  try { await navigator.clipboard.writeText(v); }
  catch { const t = document.createElement("textarea"); t.value = v; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove(); }
  toast("Nomor rekening berhasil disalin.");
}));

/* ============ RSVP & Ucapan (siap dihubungkan ke backend) ============ */
async function submitData(type, payload) {
  // Hubungkan ke Google Sheets (Apps Script) / Firebase lewat weddingConfig.rsvpEndpoint.
  if (weddingConfig.rsvpEndpoint) {
    await fetch(weddingConfig.rsvpEndpoint, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ type, ...payload, at: new Date().toISOString() }) });
  } else {
    const k = "undangan_" + type; const arr = JSON.parse(localStorage.getItem(k) || "[]"); arr.push(payload); localStorage.setItem(k, JSON.stringify(arr));
  }
}
$("#rsvpForm").addEventListener("submit", async e => {
  e.preventDefault(); const f = e.target, d = Object.fromEntries(new FormData(f));
  if (!d.name.trim()) { toast("Nama wajib diisi."); f.name.focus(); return; }
  try { await submitData("rsvp", d); f.reset(); toast("Terima kasih, konfirmasi Anda terkirim."); } catch { toast("Gagal mengirim. Coba lagi."); }
});
let wishes = [
  { name: "Keluarga Besar", text: "Selamat menempuh hidup baru. Semoga sakinah, mawaddah, warahmah." },
  { name: "Sahabat", text: "Bahagia selalu untuk kalian berdua. Semoga setiap langkah dipenuhi berkah." },
  { name: "Rekan Kerja", text: "Barakallahu lakuma wa baraka alaikuma wa jama'a bainakuma fii khair." }
];
try { wishes = [...JSON.parse(localStorage.getItem("undangan_wish") || "[]").reverse(), ...wishes]; } catch { }
function renderWishes() { $("#wishList").innerHTML = wishes.map(w => `<article class="wish"><h4>${esc(w.name)}</h4><p>${esc(w.text)}</p></article>`).join(""); }
renderWishes();
$("#wishForm").addEventListener("submit", async e => {
  e.preventDefault(); const f = e.target, d = Object.fromEntries(new FormData(f));
  if (!d.name.trim() || !d.text.trim()) { toast("Nama dan ucapan wajib diisi."); return; }
  try { await submitData("wish", d); wishes.unshift(d); renderWishes(); f.reset(); toast("Ucapan Anda terkirim. Terima kasih."); } catch { toast("Gagal mengirim. Coba lagi."); }
});

/* ============ Ripple ============ */
document.addEventListener("click", e => {
  const b = e.target.closest(".btn"); if (!b || reduce) return;
  const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2, i = document.createElement("span");
  i.className = "rip"; i.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
  b.appendChild(i); setTimeout(() => i.remove(), 700);
});

/* ============ Scroll: progress + parallax ============ */
const pxEls = $$(".px"); let ticking = false;
function onScroll() {
  const h = document.documentElement; $("#progress").style.transform = `scaleX(${h.scrollTop / (h.scrollHeight - h.clientHeight || 1)})`;
  if (!reduce) pxEls.forEach(el => { const r = el.parentElement.getBoundingClientRect(); if (r.bottom < 0 || r.top > innerHeight) return; el.firstElementChild && (el.firstElementChild.style.transform = `translate3d(0,${(r.top - innerHeight / 2) * -.12}px,0) scale(1.1)`); });
  ticking = false;
}
addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });

/* ============ Debu halus ============ */
(function dust() {
  if (reduce) return;
  const c = $("#dust"), x = c.getContext("2d"); let w, h; const n = innerWidth < 700 ? 22 : 40;
  const size = () => { w = c.width = innerWidth; h = c.height = innerHeight; }; size(); addEventListener("resize", size);
  const p = Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.4 + .3, v: Math.random() * .25 + .08, a: Math.random() * .4 + .15 }));
  (function loop() {
    x.clearRect(0, 0, w, h);
    p.forEach(q => { q.y -= q.v; q.x += Math.sin(q.y / 60) * .15; if (q.y < -4) { q.y = h + 4; q.x = Math.random() * w; } x.fillStyle = `rgba(245,190,205,${q.a})`; x.beginPath(); x.arc(q.x, q.y, q.r, 0, 6.28); x.fill(); });
    requestAnimationFrame(loop);
  })();
})();

observe(); onScroll();
